create database funcionariobd;

use funcionariobd;

create table funcionario


  ( cli_id int primary key AUTO_INCREMENT,
cli_nome varchar(30),
 cli_cpf varchar (30),
 cli_salario varchar (30));
 
 select * from funcionario;
 